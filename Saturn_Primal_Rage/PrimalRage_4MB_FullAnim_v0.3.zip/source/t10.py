import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t9.py').read().split("ORIG_MAX=1194")[0])
for p1,p2 in [(1,0),(1,5),(2,6)]:
    for st in range(8):
        try:
            m,cpu,over=run(True,p1,p2,st)
            print(p1,p2,'stage',st,'ok count',r32(m,0x060f9b3c),'free',heapfree(m)[0][1],'max low',max(over))
        except Exception as e: print(p1,p2,st,'FAIL',e)
same=True
for p1,p2 in [(2,3),(6,4),(0,1),(5,2)]:
    a,_,oa=run(False,p1,p2); b,_,ob=run(True,p1,p2,cart=0xff)
    for addr,n in [(0x0605eb00,0x5dc0),(0x060da8b4,0x3800),(0x060feb50,8),(0x0605daf4,8),(0x060f3644,8)]:
        if mem(a,addr,n)!=mem(b,addr,n): same=False; print('diff',p1,p2,hex(addr))
print('no-cart patched == original:',same)
