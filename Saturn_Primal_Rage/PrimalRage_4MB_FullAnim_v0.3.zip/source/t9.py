import sys, struct; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t3.py').read().split("if __name__=='__main__'")[0])
F001=open(DISC+'F001.PRF','rb').read(); F095=open(DISC+'F095.PRF','rb').read()
def nimg(k): return struct.unpack('>H',open(DISC+'F%03d.PRF'%k,'rb').read()[:2])[0]
def run(patched,p1,p2,st=0,cart=0x5c):
    m,cpu=make('out/F000.PRF' if patched else 'disc/F000.PRF',cart); boot(m,cpu,patched)
    d,o=m.find(0x0605eb00); d[o:o+len(F001)]=F001          # boot-time front-end table
    m.w(0x060f954c,4,st)
    cpu.call(0x0600c714,p1,p2)
    d,o=m.find(0x0605eb00); tbl=bytes(d[o:o+0x5dc0])
    over=[i for i in range(2352) if tbl[i*10:i*10+10]!=F001[i*10:i*10+10]]
    return m,cpu,over
def mem(m,a,n):
    d,o=m.find(a); return bytes(d[o:o+n])
ORIG_MAX=1194
bad=0
for p1 in range(7):
  for p2 in range(7):
    m,cpu,over=run(True,p1,p2)
    flag=m.r(0x0605c981,1); cnt=r32(m,0x060f9b3c); lo,hi=r32(m,0x002ff800),r32(m,0x002ff804)
    if flag!=0xff:   # mirror / clone -> must equal original
        mo,co,overo=run(False,p1,p2)
        same = mem(m,0x060da8b4,0x3800)==mem(mo,0x060da8b4,0x3800) and r32(m,0x060feb54)==r32(mo,0x060feb54) and over==overo and r32(m,0x0605daf4)==0x060656d0
        print(f'{p1}v{p2} original path  identical-to-original={same}')
        bad+= not same; continue
    ok_hb1 = mem(m,0x060da8b4,0x3000)==F095[(40+6*p1)*2048:(40+6*p1)*2048+0x3000]
    ok_hb2 = mem(m,0x02600000,0x3000)==F095[(40+6*p2)*2048:(40+6*p2)*2048+0x3000] and r32(m,0x060feb54)==0x22600000 and r32(m,0x060feb50)==0x060da8b4
    ok_tail= mem(m,0x02603000,0x800)==mem(m,0x060dd8b4,0x800)
    ok_base= r32(m,0x060f3648)==2760 and lo==2760 and hi==2760+nimg(53+2*p2)
    ok_rec = 0x0605eb00+cnt*10 <= 0x06068400 and r32(m,0x0605daf4)==0x06068400
    ok_fe  = (max(over) if over else 0) < ORIG_MAX
    # P2 data correctness via the real decode path
    d2=open(DISC+'F%03d.PRF'%(53+2*p2),'rb').read(); badimg=0
    for idx in range(lo,hi,7):
        a=decode(m,cpu,idx,True)
        if not (0x02400000<=a<0x02600000) or d2.find(mem(m,a,24))<0: badimg+=1
    d1=open(DISC+'F%03d.PRF'%(53+2*p1),'rb').read()
    for idx in range(r32(m,0x060f3644), r32(m,0x060f3644)+nimg(53+2*p1),7):
        a=decode(m,cpu,idx,True)
        if 0x02400000<=a<0x02800000 or d1.find(mem(m,a,24))<0: badimg+=1
    allok= ok_hb1 and ok_hb2 and ok_tail and ok_base and ok_rec and ok_fe and badimg==0
    bad+= not allok
    print(f'{p1}v{p2} cart path hb1={ok_hb1} hb2={ok_hb2} tail={ok_tail} base={ok_base} records<heap={ok_rec} frontend-safe={ok_fe} (max low slot {max(over)}) count={cnt} badimg={badimg} free={heapfree(m)}')
print('FAILURES',bad)
