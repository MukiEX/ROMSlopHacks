import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t11.py').read().split("if __name__=='__main__'")[0])
bad=0
for p1,p2 in [(2,3),(6,4),(0,1),(5,2),(3,3),(0,5)]:
    mo,co,cmo=run(False,p1,p2,cart=0xff); mp,cp,cmp_=run(True,p1,p2,cart=0xff)
    oo=[x[1] for x in mo.log if x[0]=='open']; op=[x[1] for x in mp.log if x[0]=='open']
    hb = mem(mo,0x060da8b4,0x3800)==mem(mp,0x060da8b4,0x3800) and mem(mo,0x060feb50,8)==mem(mp,0x060feb50,8)
    same_count = r32(mo,0x060f9b3c)==r32(mp,0x060f9b3c)
    okd=True
    for fid,lo in [(oo[1],r32(mp,0x060f3644)),(oo[-1],cmp_)]:
        ok,_,_=check_set(mp,cp,True,fid,lo,nimg(fid),{'wramL','hwram'}); okd&=ok
    print(p1,p2,'no-cart: same files',oo==op,'same image count',same_count,'hitbox same',hb,'data ok',okd)
    bad+= not (oo==op and same_count and hb and okd)
print('BAD',bad)
