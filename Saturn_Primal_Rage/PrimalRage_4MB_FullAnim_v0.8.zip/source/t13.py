import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t11.py').read().split("if __name__=='__main__'")[0])
def run_forced(patched,p1,p2,a,b):
    m,cpu=make('out/F000.PRF' if patched else 'disc/F000.PRF'); boot(m,cpu,patched)
    d,o=m.find(0x0605eb00); d[o:o+len(F001)]=F001
    cpu.call(0x0600c714,p1,p2); cm=r32(m,0x060f9b3c); cpu.call(0x0600c7f4,p1,p2)
    seq=[a,b]
    def rnd(c): c.R[0]=seq.pop(0)
    m.hooks[0x060362dc]=rnd
    cpu.call(0x0600c820); del m.hooks[0x060362dc]
    return m,cpu,cm
bad=0
for p1,p2 in [(1,1),(3,3),(0,0),(1,6),(6,1),(2,6),(1,0),(1,5)]:
    for a in range(3):
        for b in range(3):
            for patched in (False,True):
                try:
                    m,cpu,cm=run_forced(patched,p1,p2,a,b)
                    extra=[x[1] for x in m.log if x[0]=='open'][-1]
                    ok,rg,_=check_set(m,cpu,patched,extra,cm,nimg(extra),None)
                    tag='ok' if ok else 'DATA-BAD'
                    if patched and not ok: bad+=1
                    if patched: print(f'{p1}v{p2} F{extra} patched {tag} {sorted(rg)} free={[f[1] for f in heapfree(m)]}')
                except Exception as e:
                    print(f'{p1}v{p2} a{a}b{b}', 'patched' if patched else 'orig', 'CRASH', e)
                    if patched: bad+=1
print('BAD',bad)
