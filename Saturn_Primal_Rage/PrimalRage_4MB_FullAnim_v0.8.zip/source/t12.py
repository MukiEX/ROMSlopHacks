import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t11.py').read().split("if __name__=='__main__'")[0])
pairs=[(c,c) for c in range(7)]+[(0,5),(5,0),(1,6),(6,1)]
bad=0
for p1,p2 in pairs:
    res={}
    for patched in (False,True):
        try:
            m,cpu,cm=run(patched,p1,p2)
        except Exception as e:
            res[patched]=('CRASH',str(e)); continue
        opens=[x[1] for x in m.log if x[0]=='open']; extra=opens[-1]
        main=opens[1]
        okm,rm,_=check_set(m,cpu,patched,main,r32(m,0x060f3644),nimg(main),{'wramL','hwram'})
        okx,rx,_=check_set(m,cpu,patched,extra,cm,nimg(extra),{'wramL','hwram'})
        diffs=[hex(a) for a,n in [(0x060da8b4,0x3800),(0x060feb50,8)] if mem(m,a,n)!=mem(m,a,n)]
        res[patched]=(okm and okx, heapfree(m), mem(m,0x060da8b4,0x3800), r32(m,0x060feb54))
    o,p=res[False],res[True]
    if o[0]=='CRASH' or p[0]=='CRASH':
        print(p1,p2,'orig',o[:2],'patched',p[:2]); bad+= p[0]=='CRASH' and o[0]!='CRASH'; continue
    same_hb = o[2]==p[2] and o[3]==p[3]
    print(f'{p1}v{p2} data-ok orig={o[0]} patched={p[0]} hitbox-same={same_hb} free orig={o[1]} patched={p[1]}')
    bad+= not (p[0] and same_hb)
print('BAD',bad)
