import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t15.py').read().split("bad=0")[0])
import build; L=build.build_blob()[1]
for cart in (0x5C, 0xFF):
  for p1,p2 in [(2,6),(0,0)]:
    m,cpu,cm=run(True,p1,p2) if cart==0x5C else (None,None,None)
    if m is None:
        from test_load import make, boot
        m,cpu=make('out/F000.PRF',cart); boot(m,cpu,True)
    m.add(0x05c80000, bytes([0xab])*0x40000)
    m.zero={0x060fa4a8, 0x060f988c}
    cpu.call(0x06034464)
    m.w(0x0605c977,1,0); m.w(L["v_clr"],4,0)
    fb=m.find(0x05c80000)[0]
    def colstat():
        left=sum(1 for y in range(256) for x in range(16) if fb[y*1024+x]!=0)
        right=sum(1 for y in range(256) for x in range(16,640) if fb[y*1024+x]!=0xab)
        return left,right
    hist=[]
    for f in range(12):
        if f==3: fb[:]=bytes([0xab])*0x40000   # simulate buffer swap: other buffer full of junk
        cpu.call(L['my_titleframe'],maxsteps=3_000_000)
        hist.append((m.r(L['v_clr'],4),)+colstat())
    print('cart %02x'%cart,p1,p2,'state',m.r(0x0605c977,1),hist)
