"""Minimal SH-2 interpreter for unit-testing patch routines against the game's own code."""
import struct

M32 = 0xffffffff
def sx8(x): return x - 0x100 if x & 0x80 else x
def sx16(x): return x - 0x10000 if x & 0x8000 else x
def sx12(x): return x - 0x1000 if x & 0x800 else x

class Mem:
    def __init__(self):
        self.regions = []   # (base, bytearray)
        self.hooks = {}     # addr -> python fn(cpu) executed instead of code (acts like a function; returns via pr)
        self.log = []
    def add(self, base, data):
        self.regions.append((base, bytearray(data)))
    def find(self, a):
        a &= 0x07ffffff if (a >> 28) in (0, 2) else M32
        for b, d in self.regions:
            if b <= a < b + len(d): return d, a - b
        raise KeyError('unmapped %08x' % a)
    zero = set()
    def r(self, a, n):
        if a in self.zero: return 0
        d, o = self.find(a); return int.from_bytes(d[o:o + n], 'big')
    def w(self, a, n, v):
        self.log.append((a, n, v & ((1 << (8 * n)) - 1)))
        d, o = self.find(a); d[o:o + n] = (v & ((1 << (8 * n)) - 1)).to_bytes(n, 'big')

class CPU:
    def __init__(self, mem):
        self.m = mem; self.R = [0] * 16; self.T = 0; self.pr = 0; self.gbr = 0; self.mach = 0; self.macl = 0
        self.steps = 0
    def call(self, addr, *args, sp=0x06001f00, maxsteps=5_000_000):
        for i, a in enumerate(args): self.R[4 + i] = a & M32
        self.R[15] = sp
        self.steps = 0
        RET = 0xdead0000
        self.pr = RET
        pc = addr
        while pc != RET:
            pc = self.step(pc)
            self.steps += 1
            if self.steps > maxsteps: raise RuntimeError('too many steps')
        return self.R[0]

    def step(self, pc, in_delay=False):
        if pc in self.m.hooks and not in_delay:
            self.m.hooks[pc](self)
            return self.pr
        w = self.m.r(pc, 2)
        R = self.R; m = self.m
        n = (w >> 8) & 15; s = (w >> 4) & 15; i8 = w & 0xff; top = w >> 12
        nxt = pc + 2
        def delay(target):
            self.step(pc + 2, True); return target
        if w == 0x0009: return nxt
        if w == 0x000b: t = self.pr; return delay(t)
        if w == 0x0008: self.T = 0; return nxt
        if w == 0x0018: self.T = 1; return nxt
        if top == 0:
            lo = w & 15
            if lo == 0xa and s == 2: R[n] = self.pr; return nxt
            if lo == 0xa and s == 1: R[n] = self.macl; return nxt
            if lo == 0xa and s == 0: R[n] = self.mach; return nxt
            if w & 0xff == 0x29: R[n] = self.T; return nxt
            if lo == 7: self.macl = (R[n] * R[s]) & M32; return nxt
            if lo == 0xc: R[n] = sx8(m.r(R[0] + R[s], 1)) & M32; return nxt
            if lo == 0xd: R[n] = sx16(m.r(R[0] + R[s], 2)) & M32; return nxt
            if lo == 0xe: R[n] = m.r((R[0] + R[s]) & M32, 4); return nxt
            if lo == 4: m.w(R[0] + R[n], 1, R[s]); return nxt
            if lo == 5: m.w(R[0] + R[n], 2, R[s]); return nxt
            if lo == 6: m.w(R[0] + R[n], 4, R[s]); return nxt
            if lo == 3 and s == 0: t = pc + 4 + R[n]; self.pr = pc + 4; return delay(t & M32)
            if lo == 3 and s == 2: t = pc + 4 + R[n]; return delay(t & M32)
            if lo == 2 and s == 1: R[n] = self.gbr; return nxt
            if lo == 2 and s == 0: R[n] = getattr(self,'sr',0xf0) & ~1 | self.T; return nxt
        if top == 1: m.w(R[n] + (w & 15) * 4, 4, R[s]); return nxt
        if top == 2:
            d = w & 15
            if d == 0: m.w(R[n], 1, R[s]); return nxt
            if d == 1: m.w(R[n], 2, R[s]); return nxt
            if d == 2: m.w(R[n], 4, R[s]); return nxt
            if d in (4, 5, 6):
                sz = {4: 1, 5: 2, 6: 4}[d]; R[n] = (R[n] - sz) & M32; m.w(R[n], sz, R[s]); return nxt
            if d == 8: self.T = int((R[n] & R[s]) == 0); return nxt
            if d == 9: R[n] &= R[s]; return nxt
            if d == 0xa: R[n] ^= R[s]; return nxt
            if d == 0xb: R[n] |= R[s]; return nxt
            if d == 0xe: R[n] = ((R[n] & 0xffff) * (R[s] & 0xffff)) & M32; self.macl = R[n]; R[n] = R[n]; return nxt
            if d == 0xf:
                self.macl = (sx16(R[n] & 0xffff) * sx16(R[s] & 0xffff)) & M32; return nxt
        if top == 3:
            d = w & 15; a = R[n]; b = R[s]
            sa = a - (1 << 32) if a >> 31 else a; sb = b - (1 << 32) if b >> 31 else b
            if d == 0: self.T = int(a == b); return nxt
            if d == 2: self.T = int(a >= b); return nxt
            if d == 3: self.T = int(sa >= sb); return nxt
            if d == 6: self.T = int(a > b); return nxt
            if d == 7: self.T = int(sa > sb); return nxt
            if d == 8: R[n] = (a - b) & M32; return nxt
            if d == 0xc: R[n] = (a + b) & M32; return nxt
        if top == 4:
            lo = w & 0xff; a = R[n]
            if lo == 0x0b: t = R[n]; self.pr = pc + 4; return delay(t)
            if lo == 0x2b: t = R[n]; return delay(t)
            if lo == 0x22: R[n] = (R[n] - 4) & M32; m.w(R[n], 4, self.pr); return nxt
            if lo == 0x26: self.pr = m.r(R[n], 4); R[n] = (R[n] + 4) & M32; return nxt
            if lo == 0x13: R[n] = (R[n] - 4) & M32; m.w(R[n], 4, self.gbr); return nxt
            if lo == 0x17: self.gbr = m.r(R[n], 4); R[n] = (R[n] + 4) & M32; return nxt
            if lo == 0x1e: self.gbr = R[n]; return nxt
            if lo == 0x0e: self.sr = R[n]; self.T = R[n] & 1; return nxt
            if lo == 0x07: self.sr = m.r(R[n], 4); self.T = self.sr & 1; R[n] = (R[n] + 4) & M32; return nxt
            if lo == 0x03: R[n] = (R[n] - 4) & M32; m.w(R[n], 4, getattr(self,'sr',0xf0) & ~1 | self.T); return nxt
            if lo == 0x10: R[n] = (a - 1) & M32; self.T = int(R[n] == 0); return nxt
            if lo == 0x11: self.T = int(not (a >> 31)); return nxt
            if lo == 0x15: self.T = int(not (a >> 31) and a != 0); return nxt
            if lo == 0x00 or lo == 0x20: self.T = a >> 31; R[n] = (a << 1) & M32; return nxt
            if lo == 0x01: self.T = a & 1; R[n] = a >> 1; return nxt
            if lo == 0x21: self.T = a & 1; R[n] = ((a >> 1) | (a & 0x80000000)) & M32; return nxt
            if lo == 0x08: R[n] = (a << 2) & M32; return nxt
            if lo == 0x09: R[n] = a >> 2; return nxt
            if lo == 0x18: R[n] = (a << 8) & M32; return nxt
            if lo == 0x19: R[n] = a >> 8; return nxt
            if lo == 0x28: R[n] = (a << 16) & M32; return nxt
            if lo == 0x29: R[n] = a >> 16; return nxt
        if top == 5: R[n] = m.r((R[s] + (w & 15) * 4) & M32, 4); return nxt
        if top == 6:
            d = w & 15; b = R[s]
            if d == 0: R[n] = sx8(m.r(b, 1)) & M32; return nxt
            if d == 1: R[n] = sx16(m.r(b, 2)) & M32; return nxt
            if d == 2: R[n] = m.r(b, 4); return nxt
            if d == 3: R[n] = b; return nxt
            if d in (4, 5, 6):
                sz = {4: 1, 5: 2, 6: 4}[d]; v = m.r(b, sz)
                if n != s: R[s] = (b + sz) & M32
                R[n] = (sx8(v) if sz == 1 else sx16(v) if sz == 2 else v) & M32; return nxt
            if d == 7: R[n] = (~b) & M32; return nxt
            if d == 8: R[n] = (b & 0xffff0000) | ((b & 0xff) << 8) | ((b >> 8) & 0xff); return nxt
            if d == 9: R[n] = ((b << 16) | (b >> 16)) & M32; return nxt
            if d == 0xb: R[n] = (-b) & M32; return nxt
            if d == 0xc: R[n] = b & 0xff; return nxt
            if d == 0xd: R[n] = b & 0xffff; return nxt
            if d == 0xe: R[n] = sx8(b & 0xff) & M32; return nxt
            if d == 0xf: R[n] = sx16(b & 0xffff) & M32; return nxt
        if top == 7: R[n] = (R[n] + sx8(i8)) & M32; return nxt
        if top == 8:
            d = w & 15
            if n == 0: m.w(R[s] + d, 1, R[0]); return nxt
            if n == 1: m.w(R[s] + d * 2, 2, R[0]); return nxt
            if n == 4: R[0] = sx8(m.r(R[s] + d, 1)) & M32; return nxt
            if n == 5: R[0] = sx16(m.r(R[s] + d * 2, 2)) & M32; return nxt
            if n == 8: self.T = int(R[0] == (sx8(i8) & M32)); return nxt
            t = pc + 4 + sx8(i8) * 2
            if n == 9: return t if self.T else nxt
            if n == 0xb: return nxt if self.T else t
            if n == 0xd: c = self.T; self.step(pc + 2, True); return t if c else pc + 4
            if n == 0xf: c = self.T; self.step(pc + 2, True); return pc + 4 if c else t
        if top == 9: R[n] = sx16(m.r(pc + 4 + i8 * 2, 2)) & M32; return nxt
        if top == 0xa: return delay(pc + 4 + sx12(w & 0xfff) * 2)
        if top == 0xb: self.pr = pc + 4; return delay(pc + 4 + sx12(w & 0xfff) * 2)
        if top == 0xc:
            if n == 7: R[0] = ((pc + 4) & ~3) + i8 * 4; return nxt
            if n == 8: self.T = int((R[0] & i8) == 0); return nxt
            if n == 9: R[0] &= i8; return nxt
            if n == 0xa: R[0] ^= i8; return nxt
            if n == 0xb: R[0] |= i8; return nxt
        if top == 0xd: R[n] = m.r(((pc + 4) & ~3) + i8 * 4, 4); return nxt
        if top == 0xe: R[n] = sx8(i8) & M32; return nxt
        raise NotImplementedError('%08x: %04x' % (pc, w))
