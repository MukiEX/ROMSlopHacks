import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t11.py').read().split("if __name__=='__main__'")[0])
def score_screen(m,cpu):
    cpu.call(r32(m,0x0602d6dc))          # heap init via the score screen's own literal
    cpu.call(0x06036c78)
    c0=r32(m,0x060f9b3c)
    fid=cpu.call(0x0602d414, m.r(0x0605c999,1), 0)
    cpu.call(0x06036ea0, fid, 1)
    return fid, c0, r32(m,0x060f9b3c)
bad=0
for p1,p2 in [(2,6),(0,1),(6,2),(3,3),(1,6),(4,5),(5,0)]:
    out={}
    for patched in (False,True):
        try:
            m,cpu,cm=run(patched,p1,p2)
            fid,c0,c1=score_screen(m,cpu)
            ok,rg,_=check_set(m,cpu,patched,fid,c0,nimg(fid),{'wramL','hwram'})
            rec_end=0x0605eb00+c1*10
            # heap header sanity: walk both chains
            chains_ok=True
            for slot in (0x0605daf4,0x0605daf8):
                b=r32(m,r32(m,slot)); k=0
                while b and k<1000:
                    if not (0x00200000<=b<0x00300000 or 0x06000000<=b<0x06100000): chains_ok=False;break
                    b=r32(m,b); k+=1
            cpu.call(r32(m,0x0603455c))   # front-end init's heap init (big variant)
            out[patched]=(fid,c0,c1,ok,sorted(rg),hex(rec_end),chains_ok,r32(m,0x060f9b3c))
        except Exception as e:
            out[patched]=('CRASH',str(e))
    print(f'{p1}v{p2} orig={out[False]}\n     patched={out[True]}')
    p=out[True]
    if p[0]=='CRASH' or not (p[3] and p[6] and 0x0605eb00+p[2]*10<=0x060648c0): bad+=1
print('BAD',bad)
