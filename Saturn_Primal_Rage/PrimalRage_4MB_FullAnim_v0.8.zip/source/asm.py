"""Tiny two-pass SH-2 assembler for the patch code (subset of the ISA)."""
import re, struct

def R(s):
    s = s.strip().lower()
    m = re.fullmatch(r'r(\d+)', s)
    if not m: raise ValueError('bad reg ' + s)
    return int(m.group(1))

def imm(s, labels):
    s = s.strip()
    if s.startswith('#'): s = s[1:]
    if s in labels: return labels[s]
    if re.fullmatch(r'[\w\s+\-*()]+', s) and not re.fullmatch(r'(0x[0-9a-fA-F]+|\d+)', s):
        return eval(s, {'__builtins__': {}}, dict(labels))
    return int(s, 0)

class Asm:
    def __init__(self, org, pre=None):
        self.org = org; self.pre = dict(pre or {})
        self.lines = []

    def assemble(self, src):
        items = []
        for raw in src.strip().splitlines():
            line = raw.split(';')[0].strip()
            if not line: continue
            while ':' in line and re.match(r'^[A-Za-z_]\w*:', line):
                lab, line = line.split(':', 1)
                items.append(('label', lab.strip()))
                line = line.strip()
            if line: items.append(('ins', line))
        labels = dict(self.pre)
        for pas in range(2):
            pc = self.org; out = bytearray()
            for kind, v in items:
                if kind == 'label':
                    labels[v] = pc; continue
                op, _, args = v.partition(' ')
                args = args.strip()
                if op == '.align':
                    n = int(args)
                    while pc % n: out += b'\x00'; pc += 1
                    continue
                if op == '.long':
                    out += struct.pack('>I', imm(args, labels) & 0xffffffff if pas else 0); pc += 4; continue
                if op == '.word':
                    out += struct.pack('>H', imm(args, labels) & 0xffff if pas else 0); pc += 2; continue
                if op == '.space':
                    n = int(args, 0); out += bytes(n); pc += n; continue
                w = self.enc(op.lower(), args, pc, labels, pas)
                out += struct.pack('>H', w); pc += 2
        self.labels = labels
        return bytes(out), labels

    def enc(self, op, a, pc, L, pas):
        ps = [x.strip() for x in re.split(r',(?![^(]*\))', a)] if a else []
        def lab(x):
            return L.get(x, pc) if not pas else L[x]
        if op == 'nop': return 0x0009
        if op == 'rts': return 0x000b
        if op in ('bt', 'bf', 'bt/s', 'bf/s'):
            d = (lab(ps[0]) - pc - 4) // 2
            assert -128 <= d < 128, (op, a)
            return {'bt': 0x8900, 'bf': 0x8b00, 'bt/s': 0x8d00, 'bf/s': 0x8f00}[op] | (d & 0xff)
        if op in ('bra', 'bsr'):
            d = (lab(ps[0]) - pc - 4) // 2
            assert -2048 <= d < 2048
            return (0xa000 if op == 'bra' else 0xb000) | (d & 0xfff)
        if op == 'jsr': return 0x400b | R(ps[0][1:]) << 8
        if op == 'jmp': return 0x402b | R(ps[0][1:]) << 8
        if op == 'sts.l' and ps[0] == 'pr': return 0x4022 | R(ps[1][2:]) << 8
        if op == 'lds.l' and ps[1] == 'pr': return 0x4026 | R(ps[0][1:-1]) << 8
        if op == 'movt': return 0x0029 | R(ps[0]) << 8
        if op == 'dt': return 0x4010 | R(ps[0]) << 8
        one = {'shll2': 0x4008, 'shlr2': 0x4009, 'shll16': 0x4028, 'shlr16': 0x4029, 'shll': 0x4000, 'shlr': 0x4001, 'shll8': 0x4018}
        if op in one: return one[op] | R(ps[0]) << 8
        two = {'add': 0x300c, 'sub': 0x3008, 'and': 0x2009, 'or': 0x200b, 'xor': 0x200a, 'tst': 0x2008, 'cmp/eq': 0x3000,
               'cmp/hs': 0x3002, 'cmp/hi': 0x3006, 'cmp/ge': 0x3003, 'cmp/gt': 0x3007, 'extu.b': 0x600c, 'extu.w': 0x600d}
        if op in two and not ps[0].startswith('#'):
            return two[op] | R(ps[1]) << 8 | R(ps[0]) << 4
        if op == 'add':
            v = imm(ps[0], L); assert -128 <= v < 128; return 0x7000 | R(ps[1]) << 8 | (v & 0xff)
        if op == 'cmp/eq':
            assert R(ps[1]) == 0; v = imm(ps[0], L); assert -128 <= v < 128; return 0x8800 | (v & 0xff)
        if op in ('and', 'or', 'tst') and ps[0].startswith('#'):
            assert R(ps[1]) == 0; v = imm(ps[0], L); assert 0 <= v < 256
            return {'and': 0xc900, 'or': 0xcb00, 'tst': 0xc800}[op] | v
        if op == 'mov':
            if ps[0].startswith('#'):
                v = imm(ps[0], L); assert -128 <= v < 128, a; return 0xe000 | R(ps[1]) << 8 | (v & 0xff)
            return 0x6003 | R(ps[1]) << 8 | R(ps[0]) << 4
        if op in ('mov.l', 'mov.w', 'mov.b'):
            sz = {'mov.b': 0, 'mov.w': 1, 'mov.l': 2}[op]
            s, d = ps
            m = re.fullmatch(r'@\((\w+)\)', s)          # PC-relative literal by label
            if m and m.group(1) not in ('r0',):
                t = lab(m.group(1))
                if sz == 2:
                    base = (pc + 4) & ~3; disp = (t - base) // 4
                    assert pas == 0 or (t % 4 == 0 and 0 <= disp < 256), (a, hex(t), hex(base))
                    return 0xd000 | R(d) << 8 | (disp & 0xff)
                if sz == 1:
                    disp = (t - pc - 4) // 2
                    assert pas == 0 or (0 <= disp < 256 and t % 2 == 0), a
                    return 0x9000 | R(d) << 8 | (disp & 0xff)
            m = re.fullmatch(r'@\((-?\w+),(r\d+)\)', s)      # @(disp,Rm),Rn
            if m:
                disp = int(m.group(1), 0); rm = R(m.group(2))
                if sz == 2: assert disp % 4 == 0 and 0 <= disp < 64; return 0x5000 | R(d) << 8 | rm << 4 | disp // 4
                assert R(d) == 0
                if sz == 1: assert disp % 2 == 0 and 0 <= disp < 32; return 0x8500 | rm << 4 | disp // 2
                return 0x8400 | rm << 4 | disp
            m = re.fullmatch(r'@\((-?\w+),(r\d+)\)', d)      # Rm,@(disp,Rn)
            if m:
                disp = int(m.group(1), 0); rn = R(m.group(2))
                if sz == 2: assert disp % 4 == 0 and 0 <= disp < 64; return 0x1000 | rn << 8 | R(s) << 4 | disp // 4
                assert R(s) == 0
                if sz == 1: assert disp % 2 == 0 and 0 <= disp < 32; return 0x8100 | rn << 4 | disp // 2
                return 0x8000 | rn << 4 | disp
            m = re.fullmatch(r'@(r\d+)\+', s)
            if m: return 0x6004 | sz | R(d) << 8 | R(m.group(1)) << 4
            m = re.fullmatch(r'@-(r\d+)', d)
            if m: return 0x2004 | sz | R(m.group(1)) << 8 | R(s) << 4
            m = re.fullmatch(r'@(r\d+)', s)
            if m: return 0x6000 | sz | R(d) << 8 | R(m.group(1)) << 4
            m = re.fullmatch(r'@(r\d+)', d)
            if m: return 0x2000 | sz | R(m.group(1)) << 8 | R(s) << 4
        raise ValueError('cannot encode: %s %s' % (op, a))
