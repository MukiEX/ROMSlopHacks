import sys, struct; sys.path.insert(0,'/home/claude/pr')
from test_load import *
def r32(m,a): return m.r(a,4)
def heapfree(m):
    out=[]
    for slot in (0x0605daf4,0x0605daf8):
        h=r32(m,slot); tot=0; big=0; b=r32(m,h)
        while b:
            s_=r32(m,b+4); tot+=s_; big=max(big,s_); b=r32(m,b)
        out.append((hex(h),tot,big))
    return out
import build
LB=build.build_blob()[1]
F001=open(DISC+'F001.PRF','rb').read(); F095=open(DISC+'F095.PRF','rb').read()
def nimg(k): return struct.unpack('>H',open(DISC+'F%03d.PRF'%k,'rb').read()[:2])[0]
def mem(m,a,n):
    d,o=m.find(a); return bytes(d[o:o+n])
def dec(m,cpu,idx,patched):
    w=r32(m,0x0605eb00+idx*10); off=(w&0xfffff)<<2
    if not patched: return ((off&0x1fffff)|0x06000000) if off&0x200000 else (off|0x200000)
    cpu.R[5]=off; cpu.call(LB['my_decode']); return cpu.R[5]
def run(patched,p1,p2,st=0,cart=0x5c,attract=True):
    m,cpu=make('out/F000.PRF' if patched else 'disc/F000.PRF',cart); boot(m,cpu,patched)
    d,o=m.find(0x0605eb00); d[o:o+len(F001)]=F001
    m.w(0x060f954c,4,st)
    cpu.call(0x0600c714,p1,p2)
    c_after_match=r32(m,0x060f9b3c)
    if attract:
        cpu.call(0x0600c7f4,p1,p2); cpu.call(0x0600c820)
    return m,cpu,c_after_match
def region(a):
    if 0x02500000<=a<0x02600000 or 0x02700000<=a<0x02800000: return 'cart'
    if 0x00200000<=a<0x00300000: return 'wramL'
    if 0x06000000<=a<0x06100000: return 'hwram'
    return 'BAD'
def check_set(m,cpu,patched,fid,lo,n,expect):
    d=open(DISC+'F%03d.PRF'%fid,'rb').read(); bad=0; regs=set()
    for idx in range(lo,lo+n):
        a=dec(m,cpu,idx,patched); r=region(a); regs.add(r)
        if r=='BAD' or d.find(mem(m,a,24))<0: bad+=1
    ok = bad==0 and (expect is None or regs<=expect)
    return ok, regs, bad
if __name__=='__main__':
  FAILS=0
  for p1 in range(7):
    for p2 in range(7):
      m,cpu,cm=run(True,p1,p2)
      opens=[x[1] for x in m.log if x[0]=='open']; extra=opens[-1]
      flag=m.r(0x0605c981,1)
      if flag!=0xff:
          mo,co,_=run(False,p1,p2)
          same = all(mem(m,a,n)==mem(mo,a,n) for a,n in [(0x0605eb00,0x5dc0),(0x060da8b4,0x3800),(0x060feb50,8)])
          FAILS+= not same; print(f'{p1}v{p2} original path identical={same}'); continue
      b1=r32(m,0x060f3644); b2=r32(m,0x060f3648)
      ok1,r1,_=check_set(m,cpu,True,53+2*p1,b1,nimg(53+2*p1),{'wramL','hwram'})
      ok2,r2,_=check_set(m,cpu,True,53+2*p2,b2,nimg(53+2*p2),{'cart'})
      okx,rx,_=check_set(m,cpu,True,extra,cm,nimg(extra),None)
      hb = mem(m,0x060da8b4,0x3000)==F095[(40+6*p1)*2048:(40+6*p1)*2048+0x3000] and mem(m,0x02400000,0x3000)==F095[(40+6*p2)*2048:(40+6*p2)*2048+0x3000] and r32(m,0x060feb54)==0x22400000
      cnt=r32(m,0x060f9b3c); rec_ok=0x0605eb00+cnt*10<=0x0606B000
      tbl=mem(m,0x0605eb00,len(F001)); over=[i for i in range(2352) if tbl[i*10:i*10+10]!=F001[i*10:i*10+10]]
      fe_ok=max(over)<1194
      allok=ok1 and ok2 and okx and hb and rec_ok and fe_ok and b2==2760
      FAILS+= not allok
      print(f'cnt={cnt} {p1}v{p2} P1{sorted(r1)} P2{sorted(r2)} extra F{extra:03d}{sorted(rx)} ok={ok1},{ok2},{okx} hitbox={hb} records={rec_ok} frontend={fe_ok} heap={heapfree(m)}')
  print('FAILS',FAILS)
