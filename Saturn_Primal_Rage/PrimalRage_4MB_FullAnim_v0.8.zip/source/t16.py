import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t15.py').read().split("bad=0")[0])
def cycle(patched,p1,p2):
    m,cpu,cm=run(patched,p1,p2)
    m.zero={0x060fa4a8, 0x060f988c}
    score_screen(m,cpu)
    cpu.call(0x06034464)                  # front-end init (title return)
    cpu.call(0x060366d4); cpu.call(r32(m,0x0602596c))
    return m,cpu
regions=[('img table',0x0605eb00,0x5dc0),('F002',0x060648c0,100),('VDP1',0x05c00000,0x80000),('VDP2',0x05e00000,0x80000),('VDP2regs',0x05f80000,0x200)]
ptrs=[0x060f8000,0x060fd394,0x060f7ffc,0x060fe6a0,0x060fd390]
for p1,p2 in [(2,6),(0,1),(4,5),(6,2),(3,3)]:
    a,ca=cycle(False,p1,p2); b,cb=cycle(True,p1,p2)
    print(f'{p1}v{p2}')
    for name,base,n in regions:
        x=mem(a,base,n); y=mem(b,base,n)
        diff=[i for i in range(n) if x[i]!=y[i]]
        print(f'   {name}: {len(diff)} bytes differ', (hex(base+diff[0]),hex(base+diff[-1])) if diff else '')
    for p in ptrs:
        va,vb=r32(a,p),r32(b,p)
        same = va==vb
        print(f'   buffer ptr {hex(p)}: orig {hex(va)} patched {hex(vb)}', '' if same else '<-- DIFFERENT')
