PRIMAL RAGE (USA, Sega Saturn) - 4MB RAM CART FULL-ANIMATION HACK  v0.8
=====================================================================================================

Apply to:  Primal Rage (USA) (Track 01).bin   (redump, Mode 1/2352)
           CRC32 before: 5AFEE626   after: 6A0B97BF (default) / 150105C6 (uncached variant)
Patches:   .bps (Floating IPS, ROM Patcher JS, beat) or .ips. Only Track 01 changes; keep your .cue
           and the audio tracks as they are.

Changes in v0.8 (clears the garbage column on the title screen)
----------------------------------------------------------------
The title screen never draws anything in the leftmost 8 pixels, and the game never wipes the
sprite framebuffer on its own (its hardware erase area is set to nothing at boot). Whatever the
previous screen left there stayed visible on the title. It showed up mostly when a demo went
straight to the title (pressing Start during a demo, or the demos that skip the score screen).
- The front end's per-frame call to the title routine (literal @0x06026644 -> 0x06025628) now
  goes through my_titleframe. While the title is in its entry state (0x0605C977 = 0) and for
  8 frames after, it writes black/transparent to x 0-7 of all 256 lines of the VDP1 draw buffer
  (0x25C80000) before running the original routine. Because the buffers swap every frame, both
  get cleared while the screen is still fading in. Nothing else changes, with or without a cart.
- The unused my_draw/my_reset routines were removed. The patch code is 960 bytes and still fits
  in the reserved 1KB.

Changes in v0.7 (fixes the missing fighter and crash on the score screen after a cart match)
---------------------------------------------------------------------------------------------
The score screen (and other screens after a match) resets the heap and loads its own sprites
without resetting the image counter. After a cart match the counter sits at slot 2760+, so those
new image records were written into the area reserved for P2's records. The screen's heap reset
had just handed that same memory back to the game. Records and sprite data overwrote each other:
the animated fighter vanished, then the game crashed.
- Every other heap-init call site (the score screen, front end, endings and movie code; literals
  @0x0602D6DC, 0x0602F2C0, 0x0602F348, 0x06035134, 0x060391F0 and the large front-end variant
  @0x06034334, 0x0603455C) now goes through a wrapper. It runs the original heap init, and if the
  image counter is still in P2's range, rewinds it to where P1's sets ended. Later loads then
  number their images in the same low range the original game uses after a match.
- The cart-match record area grew to slots up to 5065 (heap start 0x0606B000) for extra margin.

Changes in v0.6 (fixes the attract-mode / arcade hang on real hardware)
-----------------------------------------------------------------------
After the match loader, attract mode and arcade mode call 0x0600C820, which loads one more
compressed sprite set (F124-F132, picked at random, about 48KB). VS mode doesn't. The original
game leaves enough room for it, but v0.4/v0.5 cart matches didn't: Work RAM-L is full with P1's
full set, and the image-record area takes high RAM. The allocation failed and the game hung.
- Player 2's set now lives in two 1MB cart windows (0x02500000 and 0x02700000). After it
  loads, the leftover cart space (about 580KB) is linked onto the end of the game's Work RAM-L
  free list, so later loads in the match can use it.
- Cart data is recognized by address: its offset always has bit 20 set, which Work RAM data
  never does. The image-number range tracking, and the two hooks it needed, are gone.
- The record area for image slots 2760+ is larger (heap start 0x06069600, room up to slot 4400).
  The measured peak is 3,950.
- The patch code is now 860 bytes and reserves only the last 1KB of Work RAM-L (was 2KB). Mirror
  matches are tight on memory even in the original game, so this matters.
- P2's hitbox table moved to cart offset 0 (0x22400000).

Changes in v0.5
---------------
The Time Warner and Probe logo movies at startup can now be skipped with Start, like the intro
movie. The startup code (0x06022E02) called the movie player 0x060391B0 with the no-skip flag set
to 1 for movies 0 and 1. Both calls now pass 0, the value the intro (movie 2) already uses. The
ending movies are unchanged. This works with or without the cart.

Changes in v0.4 (fixes the black-screen hang on real hardware)
---------------------------------------------------------------
v0.1-v0.3 switched GFS to transfer mode 0 for P2's read into the cart, wrongly assuming mode 0 was
CPU copy. The library's mode table at 0x0603F568 shows mode 0 is SCU DMA (0x0603F998), and the
game's default mode 3 is already a CPU copy loop (0x0603FBF0). SCU DMA can't write to the cart, so
the first cart load hung on a real Saturn (the MiSTer core let it through). v0.4 doesn't touch the
transfer mode, so every read uses the game's own CPU copy, which writes to the cart fine.

Changes in v0.3 (fixes for two bugs in v0.1/v0.2 cart matches)
----------------------------------------------------------------
1. Hit/hurt boxes. The game keeps a per-image hitbox table for each fighter (from F095), indexed by
   image number. v0.2 loaded full image sets but kept the reduced-set tables, so collision boxes
   came from the wrong entries. Cart matches now load each fighter's full-set table, the same
   one mirror matches use: P1's at 0x060DA8B4, P2's in the cart at 0x22600000.
2. Garbage on the LOADING/title screens after cart matches (the column at the left edge). The
   front-end's image table (F001, loaded once at boot) shares slots with match images. The
   original game never uses more than 1,194 slots in a match, while v0.2 used up to 1,918 and
   overwrote front-end entries. P2's images, and everything loaded after them, are now numbered
   from slot 2,760. Their records sit just past the front-end data. In cart matches the
   high-RAM heap starts 11KB later (0x06068400) to make room. P1's images stay below slot 1,015.

What it does
------------
With a 4MB Extended RAM Cartridge (ID 0x5C) inserted, normal (non-mirror) matches load the full
"mirror match" animation set for BOTH fighters:
  - Player 1's full set goes into Work RAM, exactly where a mirror match would put it.
  - Player 2's full set (~1.47MB) goes into two 1MB windows of the cart. The rest of the cart's
    free space is shared with the game for any later loads in the match.
Without the cart (or with a 1MB cart), the game runs the original code path unchanged.

Cart indicator: when a 4MB cart is detected, the title screen shows "4MB RAM CART ACTIVE" in
the large title font, centered directly under the "SATURN V1.4U" version line. It uses the same
check the loader does (cart ID 0x5C), so if you see the line, the full-animation loading is on.
No line means the game will use its normal reduced sets.
Mirror matches and the two clone pairings (T-rex vs T-rex, ape vs ape) are also left on the
original path; they already use large sets.

How it works (addresses are RAM addresses; the executable F000.PRF loads at 0x06004000)
-------------------------------------------------------------------------------------
- Boot entry (literal @0x06004008) now runs a stub that copies 960 bytes of hack code to the
  last 1KB of Work RAM-L (0x002FFC00). The KRB1 heap is shortened by 1KB (literal @0x06036130).
- Match loader's fighter call (literal @0x0600C7E0) -> my_fighter. When the cart is present and
  the match is normal, it loads the compressed set F(053+2c) for each player, plus that player's
  normal VDP1-resident set F(036+2c). For P2 it initializes the cart (0x257EFFFE=1,
  ASR0=0x23301FF0, AREF=0x13), builds two 1MB heaps in the cart (0x02500000, 0x02700000) and
  makes them the only heaps for P2's load. It then restores the heap list and links the cart
  heaps' remaining free blocks onto the end of the Work RAM-L free chain. The CD reads use the game's own CPU-copy transfer mode, which can
  write to the cart.
- Relocation (literal @0x06037074) -> my_reloc: cart addresses are stored as a cart-relative offset.
- The source decode inside 0x06034608 (0x0603466C-0x0603467F) calls my_decode. If the image's
  byte offset has bit 20 set, it returns 0x02400000 + offset (cart). Otherwise it uses the
  original Work RAM-L/H decode.
- Stage loader's heap init (literal @0x0603518C) -> my_heapinit: in a cart match, the KRBM heap
  starts at 0x0606B000 so image records for slots 2760-5065 fit at 0x060656D0-0x0606AFFF. It
  also sets the flag my_hitbox checks.
- Match loader's hitbox load (literal @0x0600C7EC) -> my_hitbox: after the original 0x06035398, a
  cart match loads the 12KB full-set tables from F095 sector 40+6c for both players. P1's goes to
  0x060DA8B4. P2's goes to the cart at 0x22400000, followed by the 2KB that mirror matches read
  past the end of the table. The P2 table pointer at 0x060FEB54 is set to it.
- In my_fighter, P2 is numbered from image slot 2760, and P2's image base (0x060F3648) is set
  to match.
- Title screen (literal @0x0602596C, the call that closes the title text block right after the
  version line) -> my_title. If cart ID is 0x5C it calls the game's own print routine
  0x0603662C(x=centered, row 6, "4MB RAM CART ACTIVE", attr 0x4003, the version line's style),
  then continues to 0x060366E8.

Variants
--------
Default: the decompressor reads the cart through the cached address 0x024xxxxx, the same way the
game reads its own sprite data in Work RAM.
"uncached cart reads": reads via 0x224xxxxx. Use this one if player 2's sprites ever show garbage
(a stale-cache problem), at some cost in speed.

Testing done
------------
No emulator or Saturn could be run here. The patch was checked by running the game's own SH-2 code
in a purpose-built interpreter:
  - v0.7: the score screen's own sequence ran after attract-style matches: heap init through its
    own literal, 0x06036C78, the fighter file chosen by 0x0602D414, then 0x06036EA0. The
    fighter's images get slots right after P1's sets (for example 922; the original uses 1388),
    stay inside the image table and decode correctly, and the heap chains stay intact. The v0.6
    build reproduces the reported bug in the same test: slots 3700+, records inside the heap, bad
    sprite data.
  - v0.6: the full attract/arcade sequence (match loader 0x0600C714, then 0x0600C7F4, then
    0x0600C820) ran for all 49 pairings. In all 38 cart pairings, every image of P1's set, P2's
    set and the extra set decodes to the right file data, with P1's in Work RAM and P2's in the
    cart. The extra set lands in the shared cart space or high RAM. Records stay below the heap,
    front-end slots are untouched, and both hitbox tables are correct. Each of the nine extra
    files was also forced on mirror, clone and cart pairings, with no failures; the tightest case
    (1v1 with F126) still has about 1.2KB free. Without a cart, the patched game opens the same
    files, numbers the same images and builds the same hitbox tables as the original.
  - v0.4: every CD read uses the game's transfer mode 3 (CPU copy), including P2's read into the
    cart.
  - v0.3, all 49 pairings: in cart matches both hitbox tables match F095's full-set tables. P1
    never writes image slots above 1,014; the original goes up to 1,194, so front-end entries
    survive. Records stay below the moved heap, and high-RAM headroom is 28-46KB on all stages.
    Mirror and clone matches are byte-identical to the original game, and so are no-cart matches.
  - The full match loader 0x0600C714 ran for all 49 character pairings, and the heaviest pairings ran
    on all 8 stages. There were no allocation failures. Work RAM-H headroom stayed at 40-60KB, the
    same range as an unpatched mirror match. Peak use was 2,280 of 2,760 frame-ID slots and 1,918 of
    2,400 image slots.
  - Every image of both full sets decodes to the right bytes from the disc file, with P1's in
    Work RAM and P2's in the cart.
  - The real draw routine 0x06034608 receives cart source addresses for P2 and Work RAM addresses
    for P1.
  - The title text block, rendered into VDP2 memory: the new line appears on rows 6-7 under the
    version line with a 4MB cart, and nothing appears with no cart or a 1MB cart.
  - The rebuilt track's EDC/ECC was validated, and re-extracting the file system gives back the
    patched F000 with every other file byte-identical.

Things to watch when testing
----------------------------
1. Speed: P2 frames are decompressed from the cart, about 4x slower memory than Work RAM-L.
   Watch for slowdown during heavy moments.
2. A few frame IDs exist only in the reduced sets: 0x2C00 (characters 0 and 5), 0x15B8 (1), and
   0x1370/0x1371/0x13E7 (6). If one is ever requested, the game's lookup returns image 0, so one
   frame of an animation could show the wrong sprite. Mirror matches already run without these IDs.
3. Title notice placement: rows 6-7 sit right under the version line. If it overlaps artwork,
   the row is the "mov #6,r5" in my_title (source/build.py) and is easy to move.
4. Emulators: enable the 4MB Extended RAM cart (Mednafen: ss.cart "extram4", Kronos/Yabause:
   "4 Mbyte RAM" cartridge). On hardware, use an official 4MB cart or a compatible 4-in-1 /
   Action Replay cart; ODEs that expose RAM cart emulation should also work.
