"""Builds the patched executable (F000.PRF) for the Primal Rage 4MB-cart hack."""
import struct, sys
sys.path.insert(0, '/home/claude/pr')
from asm import Asm

EXE_BASE = 0x06004000
BLOB = 0x002FF800          # last 2KB of Work RAM-L, removed from the KRB1 heap
STUB = 0x060E0000          # inside BSS: only needs to live until the BSS clear at boot
CART = 0x02400000          # 4MB cart DRAM0 (cached alias of 0x22400000)

BLOB_SRC = r"""
vars:
v_lo:     .long 0          ; @0  first image index of P2's cart set
v_hi:     .long 0          ; @4  end (exclusive); lo>=hi means "no cart range"
v_cur:    .long 0          ; @8  image index being drawn
v_save0:  .long 0          ; @12 saved heap list [0]
v_save1:  .long 0          ; @16 saved heap list [1]
dummy:    .long 0          ; @20 empty heap: next=0
          .long 0          ; size=0
          .long 0

; ---------------------------------------------------------------- draw entry
; replaces the call to 0x06034608 (decompress sprite r4 = image index)
my_draw:
    mov.l @(L_vars),r1
    mov.l r4,@(8,r1)
    mov.l @(L_draw),r0
    jmp @r0
    nop

; ---------------------------------------------------------------- source decode
; called from inside 0x06034608.  in: r5 = (field & 0xfffff) << 2
; out: r5 = CPU address of compressed image.  clobbers r1,r2 only.
my_decode:
    mov.l r0,@-r15
    mov.l @(L_vars),r2
    mov.l @(8,r2),r1
    mov.l @(0,r2),r0
    cmp/hs r0,r1
    bf dec_normal
    mov.l @(4,r2),r0
    cmp/hi r1,r0
    bf dec_normal
    mov.l @(L_cartrd),r1
    bra dec_done
    add r1,r5
dec_normal:
    mov.l @(L_200000),r2
    tst r2,r5
    bt dec_wraml
    mov.l @(L_1fffff),r1
    and r1,r5
    mov.l @(L_06000000),r1
    bra dec_done
    or r1,r5
dec_wraml:
    or r2,r5
dec_done:
    rts
    mov.l @r15+,r0

; ---------------------------------------------------------------- image-table reset
; replaces the call to 0x06038250 inside 0x06036cd8 (runs whenever image indices restart)
my_reset:
    mov.l @(L_vars),r1
    mov #0,r2
    mov.l r2,@(0,r1)
    mov.l r2,@(4,r1)
    mov.l @(L_hashreset),r2
    jmp @r2
    nop

; ---------------------------------------------------------------- relocation
; replaces 0x060377f6(rec=r4, dest=r5, start=r6, end=r7) for the compressed-set loader
my_reloc:
    mov.l @(L_cart),r0
    mov r5,r1
    sub r0,r1
    mov.l @(L_400000),r0
    cmp/hs r0,r1
    bf rl_cart
    mov.l @(L_reloc),r0
    jmp @r0
    nop
rl_cart:
    shlr2 r1
    mov r7,r2
    sub r6,r2
    mov r6,r0
    shll2 r0
    add r6,r0
    add r0,r0
    add r4,r0
    mov r0,r6
    mov #15,r4
    mov.w @r6,r3
    and r4,r3
    shll16 r3
    mov.w @(2,r6),r0
    extu.w r0,r0
    or r0,r3
    sub r3,r1
    tst r2,r2
    bt rl_done
    mov #-16,r5
rl_loop:
    mov.w @r6,r3
    and r4,r3
    shll16 r3
    mov.w @(2,r6),r0
    extu.w r0,r0
    or r0,r3
    add r1,r3
    mov r3,r0
    mov.w r0,@(2,r6)
    shlr16 r3
    mov.w @r6,r0
    and r5,r0
    or r3,r0
    mov.w r0,@r6
    dt r2
    bf/s rl_loop
    add #10,r6
rl_done:
    rts
    nop

; ---------------------------------------------------------------- fighter loader
; replaces 0x060351d4(r4 = character) in the match loader 0x0600c714
my_fighter:
    mov.l @(L_flag),r1
    mov.b @r1,r0
    cmp/eq #-1,r0
    bf mf_orig
    mov.l @(L_cartid),r1
    mov.b @r1,r0
    cmp/eq #92,r0
    bt mf_cart
mf_orig:
    mov.l @(L_fighter),r0
    jmp @r0
    nop
mf_cart:
    sts.l pr,@-r15
    mov.l r8,@-r15
    mov.l r9,@-r15
    mov r4,r8
    mov.l @(L_vars),r9
    mov.l @(L_p2char),r1
    mov.b @r1,r0
    extu.b r0,r0
    cmp/eq r8,r0
    bf mf_load
    ; -- player 2: enable cart, build a heap in it, make it the only heap
    mov.l @(L_cartctl),r1
    mov #1,r0
    mov.w r0,@r1
    mov.l @(L_asr0),r1
    mov.l @(L_asr0val),r0
    mov.l r0,@r1
    mov.l @(L_aref),r1
    mov #19,r0
    mov.l r0,@r1
    mov.l @(L_cart),r1
    mov r1,r2
    add #12,r2
    mov.l r2,@r1
    mov #0,r0
    mov.l r0,@(4,r1)
    mov.l r0,@(8,r1)
    mov.l r0,@r2
    mov.l @(L_heapsz),r0
    mov.l r0,@(4,r2)
    mov.l @(L_magic),r0
    mov.l r0,@(8,r2)
    mov.l @(L_heaplist),r2
    mov.l @r2,r0
    mov.l r0,@(12,r9)
    mov.l @(4,r2),r0
    mov.l r0,@(16,r9)
    mov.l r1,@r2
    mov r9,r0
    add #20,r0
    mov.l r0,@(4,r2)
    ; GFS transfer mode SCU-DMA(3) -> CPU(0): SCU DMA cannot write to the cart
    mov.l @(L_tmode),r1
    mov.w @(W_e500),r0
    mov.w r0,@r1
    mov.l @(L_imgcount),r1
    mov.l @r1,r0
    mov.l r0,@(0,r9)
    mov #0,r0
    mov.l r0,@(4,r9)
mf_load:
    ; full compressed set: file 53 + 2c
    mov r8,r4
    add r4,r4
    add #53,r4
    mov.l @(L_mainload),r0
    jsr @r0
    mov #0,r5
    mov.l @(L_p2char),r1
    mov.b @r1,r0
    extu.b r0,r0
    cmp/eq r8,r0
    bf mf_sec
    ; -- player 2 done: publish range, restore heaps and transfer mode
    mov.l @(L_imgcount),r1
    mov.l @r1,r0
    mov.l r0,@(4,r9)
    mov.l @(L_heaplist),r2
    mov.l @(12,r9),r0
    mov.l r0,@r2
    mov.l @(16,r9),r0
    mov.l r0,@(4,r2)
    mov.l @(L_tmode),r1
    mov.w @(W_e503),r0
    mov.w r0,@r1
mf_sec:
    ; normal-match VDP1-resident set: file 36 + 2c
    mov r8,r4
    add r4,r4
    add #36,r4
    mov.l @(L_secload),r0
    jsr @r0
    mov #0,r5
    mov.l @r15+,r9
    mov.l @r15+,r8
    lds.l @r15+,pr
    rts
    nop

W_e500:   .word 0xe500
W_e503:   .word 0xe503
    .align 4
L_vars:     .long vars
L_draw:     .long 0x06034608
L_cart:     .long 0x02400000
L_cartrd:   .long CARTRD
L_200000:   .long 0x00200000
L_1fffff:   .long 0x001fffff
L_06000000: .long 0x06000000
L_hashreset:.long 0x06038250
L_400000:   .long 0x00400000
L_reloc:    .long 0x060377f6
L_flag:     .long 0x0605c981
L_cartid:   .long 0x24ffffff
L_fighter:  .long 0x060351d4
L_p2char:   .long 0x060feb20
L_cartctl:  .long 0x257efffe
L_asr0:     .long 0x25fe00b0
L_asr0val:  .long 0x23301ff0
L_aref:     .long 0x25fe00b8
L_heapsz:   .long 0x001fffe8
L_magic:    .long 0x4b52424d
L_heaplist: .long 0x0605daf4
L_tmode:    .long 0x06038df2
L_imgcount: .long 0x060f9b3c
L_mainload: .long 0x06036ea0
L_secload:  .long 0x06037168
blob_end:
"""

CARTRD = 0x02400000

def build_blob():
    a = Asm(BLOB, {'CARTRD': CARTRD})
    code, labels = a.assemble(BLOB_SRC)
    assert len(code) <= 0x800, len(code)
    return code, labels

def build_stub(blob_len):
    src = r"""
stub:
    mov.l @(S_src),r1
    mov.l @(S_dst),r2
    mov.l @(S_len),r3
copy:
    mov.l @r1+,r0
    mov.l r0,@r2
    dt r3
    bf/s copy
    add #4,r2
    mov.l @(S_entry),r0
    jmp @r0
    nop
    .align 4
S_src:   .long payload
S_dst:   .long %d
S_len:   .long %d
S_entry: .long 0x0604049c
payload:
""" % (BLOB, (blob_len + 3) // 4)
    code, labels = Asm(STUB).assemble(src)
    return code, labels

def build_decode_site(my_decode):
    src = """
    mov.l @(P_lit),r2
    jsr @r2
    nop
    bra resume
    nop
    nop
P_lit: .long %d
    nop
    nop
""" % my_decode
    code, _ = Asm(0x0603466c, {'resume': 0x06034680}).assemble(src)
    assert len(code) == 0x14, len(code)
    return code

def main(src_exe, out_exe):
    exe = bytearray(open(src_exe, 'rb').read())
    def put(addr, data):
        o = addr - EXE_BASE
        exe[o:o + len(data)] = data
    def get32(addr):
        return struct.unpack('>I', exe[addr - EXE_BASE:addr - EXE_BASE + 4])[0]
    def lit(addr, old, new):
        assert get32(addr) == old, (hex(addr), hex(get32(addr)), hex(old))
        put(addr, struct.pack('>I', new))

    blob, L = build_blob()
    blob = blob + bytes((-len(blob)) % 4)
    stub, SL = build_stub(len(blob))
    put(STUB, stub + blob)
    assert STUB + len(stub) + len(blob) - EXE_BASE <= len(exe)

    lit(0x06004008, 0x0604049c, STUB)            # boot entry -> stub
    lit(0x06036130, 0x000ffff4, 0x000ff7f4)      # KRB1 heap ends before BLOB
    lit(0x0600c7e0, 0x060351d4, L['my_fighter']) # match loader fighter call
    lit(0x06034ac4, 0x06034608, L['my_draw'])    # sprite decompress call
    lit(0x06037074, 0x060377f6, L['my_reloc'])   # compressed-set relocation
    lit(0x06036cf8, 0x06038250, L['my_reset'])   # image-table reset
    site = build_decode_site(L['my_decode'])
    o = 0x0603466c - EXE_BASE
    assert exe[o:o + 20].hex() == 'd236212921188904d1352519d135a001251b252b', exe[o:o+20].hex()
    put(0x0603466c, site)
    open(out_exe, 'wb').write(exe)
    return L, SL, len(blob), len(stub)

if __name__ == '__main__':
    L, SL, bl, sl = main(sys.argv[1], sys.argv[2])
    print('blob bytes', bl, 'stub bytes', sl)
    for k in ('my_draw', 'my_decode', 'my_reset', 'my_reloc', 'my_fighter', 'vars', 'blob_end'):
        print(k, hex(L[k]))
