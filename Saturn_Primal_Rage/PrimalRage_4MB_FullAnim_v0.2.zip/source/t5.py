import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t3.py').read().split("if __name__=='__main__'")[0])
for patched in (True, False):
    m,cpu=make('out/F000.PRF' if patched else 'disc/F000.PRF'); boot(m,cpu,patched)
    cpu.call(0x0600c714,2,6)
    lo,hi=(r32(m,0x002ff800),r32(m,0x002ff804)) if patched else (0,0)
    got=[]
    def cap(c): got.append((c.R[5],c.R[4])); c.R[0]=0
    m.hooks[0x06036b74]=cap
    entry = 0x002ff820 if patched else 0x06034608
    res=[]
    for idx in [5, 600, lo, (lo+hi)//2, hi-1] if patched else [5,600,1000]:
        got.clear(); sp=0x06001e00
        m.w(sp,4,0); m.w(sp+4,4,0)
        m.w(0x060f99a0,4,0)   # VRAM ring usage counter
        cpu.call(entry, idx, 0x06000800, 0, 0, sp=sp)
        rec=0x0605eb00+idx*10
        res.append((idx, hex(got[0][0]) if got else None))
    print('patched' if patched else 'orig', 'range',(lo,hi), res)
