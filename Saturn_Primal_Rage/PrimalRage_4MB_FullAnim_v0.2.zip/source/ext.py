import sys,struct,os
f=open(sys.argv[1],'rb'); out=sys.argv[2]
def sec(n):
    f.seek(n*2352+16); return f.read(2048)
pvd=sec(16); print(pvd[1:6], pvd[8:40], pvd[40:72])
root=pvd[156:156+34]
def walk(lba,size,path):
    data=b''.join(sec(lba+i) for i in range((size+2047)//2048))
    i=0
    while i<len(data):
        l=data[i]
        if l==0: i=(i//2048+1)*2048; continue
        r=data[i:i+l]; elba=struct.unpack('<I',r[2:6])[0]; esz=struct.unpack('<I',r[10:14])[0]; fl=r[25]; nl=r[32]; name=r[33:33+nl]
        i+=l
        if name in (b'\0',b'\1'): continue
        name=name.decode().split(';')[0]; p=path+'/'+name
        if fl&2: walk(elba,esz,p)
        else:
            print(f"{elba:7d} {esz:10d} {p}")
            os.makedirs(os.path.dirname(out+p),exist_ok=True)
            with open(out+p,'wb') as o:
                for k in range((esz+2047)//2048): o.write(sec(elba+k))
                o.truncate(esz)
walk(struct.unpack('<I',root[2:6])[0],struct.unpack('<I',root[10:14])[0],'')
open(out+'/IP.BIN','wb').write(b''.join(sec(i) for i in range(16)))
