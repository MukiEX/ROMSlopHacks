import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t3.py').read().split("if __name__=='__main__'")[0])
for cart in (0x5c,0xff,0x5a):
    m,cpu=make('out/F000.PRF',cart); boot(m,cpu,True)
    cpu.call(0x060366d4)
    cpu.call(0x0603662c,-1,4,0x060516b0,0x4003)
    tgt=r32(m,0x0602596c)
    cpu.call(tgt)
    print('cart id',hex(cart),'end-of-block hook ->',hex(tgt),'flags',m.r(0x0605c9a3,1),m.r(0x0605c9a4,1))
    base=(0x4003&0x7000)|0x4000
    for row in range(3,9):
        line=''
        for col in range(45):
            v=m.r(0x25e3e000+(row*64+col)*2,2)
            if v==0: line+=' '; continue
            k=v-base-0xd4f-113
            line+= chr(46+k//4) if k>=0 and k%4==0 else ('.' if k==-0x4f+ -113+0x4f+113 else '#')
        print(f'  row {row:2d}: |{line}|')
