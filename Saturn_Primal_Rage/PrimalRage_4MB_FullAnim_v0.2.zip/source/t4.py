import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t3.py').read().split("if __name__=='__main__'")[0])
for patched,p1,p2 in [(False,6,6),(False,3,3),(True,2,6),(True,6,2),(True,5,6),(True,3,6)]:
    for stage in range(8):
        m,cpu=make('out/F000.PRF' if patched else 'disc/F000.PRF'); boot(m,cpu,patched)
        m.w(0x060f954c,4,stage)
        try: cpu.call(0x0600c714,p1,p2)
        except Exception as e: print('FAIL',patched,p1,p2,stage,e); continue
        print(patched,p1,p2,'stage',stage,'ids',r32(m,0x060fef5c),'/2760 imgs',r32(m,0x060f9b3c),'/2400 vdp1ptr',hex(r32(m,0x060fd8ec)),'free',heapfree(m))
