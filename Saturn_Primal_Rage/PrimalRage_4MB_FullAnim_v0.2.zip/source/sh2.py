"""Minimal SH-2 disassembler (big-endian). dis(mem, addr) -> (text, info)"""
import struct

def s8(x): return x - 256 if x & 0x80 else x
def s12(x): return x - 4096 if x & 0x800 else x

def dis(w, pc, rd32=None, rd16=None):
    n = (w >> 8) & 15; m = (w >> 4) & 15; i8 = w & 0xff; d4 = w & 15
    top = w >> 12; info = {}
    R = lambda r: f"r{r}"
    if top == 0:
        lo = w & 0xf
        if w == 0x0009: return "nop", info
        if w == 0x000b: info['ret'] = 1; return "rts", info
        if w == 0x0008: return "clrt", info
        if w == 0x0018: return "sett", info
        if w == 0x0028: return "clrmac", info
        if w == 0x0019: return "div0u", info
        if w == 0x001b: return "sleep", info
        if w == 0x002b: info['ret'] = 1; return "rte", info
        if lo == 2: return f"stc {['sr','gbr','vbr'][m] if m<3 else '?'},{R(n)}", info
        if lo == 3 and m == 0: info['call'] = ('reg', n); return f"bsrf {R(n)}", info
        if lo == 3 and m == 2: info['jmp'] = ('reg', n); return f"braf {R(n)}", info
        if lo == 4: return f"mov.b {R(m)},@(r0,{R(n)})", info
        if lo == 5: return f"mov.w {R(m)},@(r0,{R(n)})", info
        if lo == 6: return f"mov.l {R(m)},@(r0,{R(n)})", info
        if lo == 7: return f"mul.l {R(m)},{R(n)}", info
        if lo == 0xa: return f"sts {['mach','macl','pr'][m] if m<3 else '?'},{R(n)}", info
        if lo == 0xc: return f"mov.b @(r0,{R(m)}),{R(n)}", info
        if lo == 0xd: return f"mov.w @(r0,{R(m)}),{R(n)}", info
        if lo == 0xe: return f"mov.l @(r0,{R(m)}),{R(n)}", info
        if lo == 0xf: return f"mac.l @{R(m)}+,@{R(n)}+", info
        if w & 0xff == 0x29: return f"movt {R(n)}", info
    if top == 1: return f"mov.l {R(m)},@({d4*4},{R(n)})", info
    if top == 2:
        ops = ['mov.b {m},@{n}', 'mov.w {m},@{n}', 'mov.l {m},@{n}', '?', 'mov.b {m},@-{n}', 'mov.w {m},@-{n}', 'mov.l {m},@-{n}', 'div0s {m},{n}',
               'tst {m},{n}', 'and {m},{n}', 'xor {m},{n}', 'or {m},{n}', 'cmp/str {m},{n}', 'xtrct {m},{n}', 'mulu.w {m},{n}', 'muls.w {m},{n}']
        return ops[d4].format(m=R(m), n=R(n)), info
    if top == 3:
        ops = ['cmp/eq', '?', 'cmp/hs', 'cmp/ge', 'div1', 'dmulu.l', 'cmp/hi', 'cmp/gt', 'sub', '?', 'subc', 'subv', 'add', 'dmuls.l', 'addc', 'addv']
        return f"{ops[d4]} {R(m)},{R(n)}", info
    if top == 4:
        lo = w & 0xff
        t = {0x00: 'shll', 0x01: 'shlr', 0x04: 'rotl', 0x05: 'rotr', 0x08: 'shll2', 0x09: 'shlr2', 0x10: 'dt', 0x11: 'cmp/pz', 0x15: 'cmp/pl',
             0x18: 'shll8', 0x19: 'shlr8', 0x20: 'shal', 0x21: 'shar', 0x24: 'rotcl', 0x25: 'rotcr', 0x28: 'shll16', 0x29: 'shlr16', 0x1b: 'tas.b'}
        if lo in t: return f"{t[lo]} {R(n)}", info
        if lo == 0x0b: info['call'] = ('reg', n); return f"jsr @{R(n)}", info
        if lo == 0x2b: info['jmp'] = ('reg', n); return f"jmp @{R(n)}", info
        if lo == 0x22: return f"sts.l pr,@-{R(n)}", info
        if lo == 0x26: return f"lds.l @{R(n)}+,pr", info
        if lo == 0x2a: return f"lds {R(n)},pr", info
        if lo in (0x0e, 0x1e, 0x2e): return f"ldc {R(n)},{['sr','gbr','vbr'][lo>>4]}", info
        if lo in (0x07, 0x17, 0x27): return f"ldc.l @{R(n)}+,{['sr','gbr','vbr'][lo>>4]}", info
        if lo in (0x03, 0x13, 0x23): return f"stc.l {['sr','gbr','vbr'][lo>>4]},@-{R(n)}", info
        if lo in (0x0a, 0x1a): return f"lds {R(n)},{['mach','macl'][lo>>4]}", info
        if lo in (0x06, 0x16): return f"lds.l @{R(n)}+,{['mach','macl'][lo>>4]}", info
        if lo in (0x02, 0x12): return f"sts.l {['mach','macl'][lo>>4]},@-{R(n)}", info
        if d4 == 0xf: return f"mac.w @{R(m)}+,@{R(n)}+", info
    if top == 5: return f"mov.l @({d4*4},{R(m)}),{R(n)}", info
    if top == 6:
        ops = ['mov.b @{m},{n}', 'mov.w @{m},{n}', 'mov.l @{m},{n}', 'mov {m},{n}', 'mov.b @{m}+,{n}', 'mov.w @{m}+,{n}', 'mov.l @{m}+,{n}', 'not {m},{n}',
               'swap.b {m},{n}', 'swap.w {m},{n}', 'negc {m},{n}', 'neg {m},{n}', 'extu.b {m},{n}', 'extu.w {m},{n}', 'exts.b {m},{n}', 'exts.w {m},{n}']
        return ops[d4].format(m=R(m), n=R(n)), info
    if top == 7: return f"add #{s8(i8)},{R(n)}", info
    if top == 8:
        if n == 0: return f"mov.b r0,@({d4},{R(m)})", info
        if n == 1: return f"mov.w r0,@({d4*2},{R(m)})", info
        if n == 4: return f"mov.b @({d4},{R(m)}),r0", info
        if n == 5: return f"mov.w @({d4*2},{R(m)}),r0", info
        if n == 8: return f"cmp/eq #{s8(i8)},r0", info
        if n in (9, 0xb, 0xd, 0xf):
            t = pc + 4 + s8(i8) * 2; info['br'] = t; info['cond'] = 1
            if n in (0xd, 0xf): info['delay'] = 1
            return f"{ {9:'bt',0xb:'bf',0xd:'bt/s',0xf:'bf/s'}[n]} {t:08x}", info
    if top == 9:
        a = pc + 4 + i8 * 2; info['lit'] = (a, 2)
        v = rd16(a) if rd16 else None
        return f"mov.w @({a:08x}),{R(n)}" + (f"   ; ={v:#06x}" if v is not None else ""), info
    if top == 0xa:
        t = pc + 4 + s12(w & 0xfff) * 2; info['br'] = t; info['delay'] = 1
        return f"bra {t:08x}", info
    if top == 0xb:
        t = pc + 4 + s12(w & 0xfff) * 2; info['call'] = ('imm', t); info['delay'] = 1
        return f"bsr {t:08x}", info
    if top == 0xc:
        ops = {0: 'mov.b r0,@({d},gbr)', 1: 'mov.w r0,@({d2},gbr)', 2: 'mov.l r0,@({d4},gbr)', 3: 'trapa #{i}', 4: 'mov.b @({d},gbr),r0',
               5: 'mov.w @({d2},gbr),r0', 6: 'mov.l @({d4},gbr),r0', 7: 'mova @({a:08x}),r0', 8: 'tst #{i},r0', 9: 'and #{i},r0', 0xa: 'xor #{i},r0',
               0xb: 'or #{i},r0', 0xc: 'tst.b #{i},@(r0,gbr)', 0xd: 'and.b #{i},@(r0,gbr)', 0xe: 'xor.b #{i},@(r0,gbr)', 0xf: 'or.b #{i},@(r0,gbr)'}
        return ops[n].format(d=i8, d2=i8 * 2, d4=i8 * 4, i=i8, a=((pc + 4) & ~3) + i8 * 4), info
    if top == 0xd:
        a = ((pc + 4) & ~3) + i8 * 4; info['lit'] = (a, 4)
        v = rd32(a) if rd32 else None
        return f"mov.l @({a:08x}),{R(n)}" + (f"   ; ={v:#010x}" if v is not None else ""), info
    if top == 0xe: return f"mov #{s8(i8)},{R(n)}", info
    return f".word {w:#06x}", info


class Image:
    def __init__(self, data, base):
        self.d = data; self.base = base
    def ok(self, a): return self.base <= a < self.base + len(self.d)
    def r16(self, a):
        a &= 0x0fffffff if (a >> 28) == 2 else 0xffffffff
        return struct.unpack('>H', self.d[a - self.base:a - self.base + 2])[0] if self.ok(a) else None
    def r32(self, a):
        return struct.unpack('>I', self.d[a - self.base:a - self.base + 4])[0] if self.ok(a) else None
    def line(self, a):
        w = self.r16(a)
        t, info = dis(w, a, self.r32, self.r16)
        return t, info
    def listing(self, a, n):
        out = []
        for k in range(n):
            t, _ = self.line(a + 2 * k)
            out.append(f"{a+2*k:08x}: {self.r16(a+2*k):04x}  {t}")
        return "\n".join(out)
