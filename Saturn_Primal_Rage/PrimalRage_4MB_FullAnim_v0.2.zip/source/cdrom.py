"""Mode 1 sector EDC/ECC (ECMA-130) for rebuilding raw 2352-byte tracks."""
EDC = []
for i in range(256):
    e = i
    for _ in range(8):
        e = (e >> 1) ^ (0xD8018001 if e & 1 else 0)
    EDC.append(e)
F = [0] * 256; B = [0] * 256
for i in range(256):
    j = (i << 1) ^ (0x11D if i & 0x80 else 0)
    F[i] = j & 0xff; B[i ^ j & 0xff] = i

def edc(data):
    e = 0
    for b in data: e = (e >> 8) ^ EDC[(e ^ b) & 0xff]
    return e

def ecc_block(sec, major_count, minor_count, major_mult, minor_inc, dest):
    size = major_count * minor_count
    for major in range(major_count):
        index = (major >> 1) * major_mult + (major & 1)
        a = b = 0
        for minor in range(minor_count):
            t = sec[0xC + index]
            index += minor_inc
            if index >= size: index -= size
            a ^= t; b ^= t; a = F[a]
        a = B[F[a] ^ b]
        sec[dest + major] = a
        sec[dest + major + major_count] = a ^ b

def fix_mode1(sec):
    """sec: bytearray(2352) with sync/header/user data set; recompute EDC + ECC."""
    sec[0x814:0x81C] = bytes(8)
    e = edc(sec[0:0x810])
    sec[0x810:0x814] = e.to_bytes(4, 'little')
    ecc_block(sec, 86, 24, 2, 86, 0x81C)
    ecc_block(sec, 52, 43, 86, 88, 0x8C8)
    return sec
