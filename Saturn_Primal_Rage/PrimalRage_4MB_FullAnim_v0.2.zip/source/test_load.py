"""Run the game's real loaders + the patch inside the SH-2 interpreter and check where data lands."""
import sys, struct
sys.path.insert(0, '/home/claude/pr')
from emu import Mem, CPU

DISC = '/home/claude/pr/disc/'

def make(exe_path, cart_id=0x5C):
    m = Mem()
    hw = bytearray(0x100000)
    exe = open(exe_path, 'rb').read()
    hw[0x4000:0x4000 + len(exe)] = exe
    m.add(0x06000000, hw)
    m.add(0x00200000, bytes(0x100000))
    m.add(0x02400000, bytes(0x400000))
    idr = bytearray(0x100); idr[0xff] = cart_id
    m.add(0x04ffff00, idr)
    m.add(0x057ef000, bytes(0x1000))
    m.add(0x05fe0000, bytes(0x100))
    m.add(0x05c00000, bytes(0x80000)); m.add(0x05d00000, bytes(0x100))
    m.add(0x05e00000, bytes(0x80000)); m.add(0x05f80000, bytes(0x200))
    m.add(0x01000000, bytes(0x10))
    files = {}
    st = {}
    def op(c):
        fid = c.R[4]; h = 0x1000 + fid
        files[h] = open(DISC + 'F%03d.PRF' % fid, 'rb').read(); st[h] = 0
        m.log.append(('open', fid)); c.R[0] = h
    def rd(c):
        h, buf, size = c.R[4], c.R[5], c.R[6]
        d = files[h]; p = st[h]
        chunk = d[p:p + size]
        for i in range(0, len(chunk), 4):
            part = chunk[i:i + 4]
            m.w(buf + i, len(part), int.from_bytes(part, 'big'))
        st[h] = p + ((size + 2047) // 2048) * 2048
        tm = struct.unpack('>H', bytes(m.find(0x06038df2)[0][m.find(0x06038df2)[1]:m.find(0x06038df2)[1] + 2]))[0]
        m.log.append(('read', h - 0x1000, buf, size, tm & 0xff))
        c.R[0] = size
    def sk(c):
        st[c.R[4]] = c.R[5]; c.R[0] = 0
    def cl(c): c.R[0] = 0
    m.hooks.update({0x06038de4: op, 0x06038e1c: rd, 0x06038e54: sk, 0x06038e08: cl,
                    0x0604049c: lambda c: None,
                    0x06034204: lambda c: None, 0x06035144: lambda c: None, 0x060350e8: lambda c: None})
    cpu = CPU(m)
    return m, cpu

def boot(m, cpu, patched):
    if patched:
        cpu.call(0x060e0000)          # boot stub copies blob to WRAM-L, then "jumps" to 0x0604049c
    d, o = m.find(0x0605c940)
    d[o:o + 0xa21e8] = bytes(0xa21e8)   # the game's own BSS clear
    cpu.call(0x06035f68)              # heap init (as the stage loader does)
    cpu.call(0x06036cd8)              # image table / hash reset

def r32(m, a): return m.r(a, 4)

def decode(m, cpu, idx, patched):
    """Return the source address the sprite decompressor would read for image idx."""
    rec = 0x0605eb00 + idx * 10
    w = r32(m, rec)
    off = (w & 0xfffff) << 2
    if patched:
        m.w(0x002ff808, 4, idx)       # v_cur, as my_draw sets it
        cpu.R[5] = off
        cpu.call(0x002ff82a, off)
        cpu.R[5]  # result in r5
        return cpu.R[5]
    return ((off & 0x1fffff) | 0x06000000) if off & 0x200000 else (off | 0x200000)
