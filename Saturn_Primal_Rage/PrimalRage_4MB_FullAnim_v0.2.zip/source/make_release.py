import sys, struct, zlib, os
sys.path.insert(0, '/home/claude/pr')
import build
from cdrom import fix_mode1

SRC = '/mnt/user-data/uploads/Primal_Rage__USA___Track_01_.bin'
F000_LBA, F000_SIZE = 24, 1027936

def patch_track(src, exe):
    out = bytearray(src)
    nsec = (F000_SIZE + 2047) // 2048
    for k in range(nsec):
        lba = F000_LBA + k
        sec = bytearray(out[lba * 2352:(lba + 1) * 2352])
        chunk = exe[k * 2048:(k + 1) * 2048]
        user = bytearray(sec[16:16 + 2048]); user[:len(chunk)] = chunk
        if bytes(user) == bytes(sec[16:16 + 2048]): continue
        sec[16:16 + 2048] = user
        fix_mode1(sec)
        out[lba * 2352:(lba + 1) * 2352] = sec
    return bytes(out)

def vlq(n):
    o = bytearray()
    while True:
        x = n & 0x7f; n >>= 7
        if n == 0: o.append(0x80 | x); return bytes(o)
        o.append(x); n -= 1

def make_bps(src, dst, meta=b''):
    p = bytearray(b'BPS1') + vlq(len(src)) + vlq(len(dst)) + vlq(len(meta)) + meta
    i = 0; n = len(dst)
    while i < n:
        j = i
        while j < n and j < len(src) and src[j] == dst[j]: j += 1
        if j > i:
            p += vlq(((j - i - 1) << 2) | 0); i = j; continue
        j = i
        while j < n and (j >= len(src) or src[j] != dst[j] or (j + 8 < n and src[j:j+8] != dst[j:j+8])): j += 1
        p += vlq(((j - i - 1) << 2) | 1) + dst[i:j]; i = j
    p += struct.pack('<I', zlib.crc32(src)) + struct.pack('<I', zlib.crc32(dst))
    p += struct.pack('<I', zlib.crc32(p))
    return bytes(p)

def make_ips(src, dst):
    assert len(src) == len(dst)
    p = bytearray(b'PATCH'); i = 0; n = len(dst)
    while i < n:
        if src[i] == dst[i]: i += 1; continue
        j = i
        while j < n and j - i < 0xffff and (src[j] != dst[j] or src[j:j+8] != dst[j:j+8]): j += 1
        if i == 0x454F46: i -= 1
        assert i < 0x1000000
        p += i.to_bytes(3, 'big') + (j - i).to_bytes(2, 'big') + dst[i:j]; i = j
    return bytes(p + b'EOF')

def apply_bps(src, patch):
    assert patch[:4] == b'BPS1'
    pos = 4
    def rd():
        nonlocal pos
        d = 0; s = 1
        while True:
            x = patch[pos]; pos += 1
            d += (x & 0x7f) * s
            if x & 0x80: return d
            s <<= 7; d += s
    ss, ts, ms = rd(), rd(), rd(); pos += ms
    out = bytearray(); end = len(patch) - 12
    while pos < end:
        d = rd(); act = d & 3; ln = (d >> 2) + 1
        if act == 0: out += src[len(out):len(out) + ln]
        elif act == 1: out += patch[pos:pos + ln]; pos += ln
        else: raise ValueError('unsupported')
    return bytes(out)

if __name__ == '__main__':
    src = open(SRC, 'rb').read()
    os.makedirs('/home/claude/pr/release', exist_ok=True)
    for name, base in [('', 0x02400000), (' (uncached cart reads)', 0x22400000)]:
        build.CARTRD = base
        L, SL, bl, sl = build.main('/home/claude/pr/disc/F000.PRF', '/home/claude/pr/out/F000%s.PRF' % ('_uc' if base >> 28 else ''))
        exe = open('/home/claude/pr/out/F000%s.PRF' % ('_uc' if base >> 28 else ''), 'rb').read()
        dst = patch_track(src, exe)
        bps = make_bps(src, dst, b'Primal Rage (USA) - 4MB RAM cart full-animation hack')
        assert apply_bps(src, bps) == dst
        ips = make_ips(src, dst)
        stem = '/home/claude/pr/release/Primal Rage (USA) (Track 01) - 4MB Cart Full Animation' + name
        open(stem + '.bps', 'wb').write(bps)
        open(stem + '.ips', 'wb').write(ips)
        open('/home/claude/pr/out/track%s.bin' % ('_uc' if base >> 28 else ''), 'wb').write(dst)
        diff = sum(1 for k in range(0, len(src), 2352) if src[k:k+2352] != dst[k:k+2352])
        print(name or '(default)', 'sectors changed', diff, 'bps', len(bps), 'ips', len(ips),
              'src crc %08x dst crc %08x' % (zlib.crc32(src), zlib.crc32(dst)))
