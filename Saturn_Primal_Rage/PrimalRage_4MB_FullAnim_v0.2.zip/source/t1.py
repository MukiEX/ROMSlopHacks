import sys, struct
sys.path.insert(0,'/home/claude/pr')
from test_load import *

def file_fields(fid):
    d=open(DISC+'F%03d.PRF'%fid,'rb').read()
    n=struct.unpack('>H',d[:2])[0]; i=2
    while struct.unpack('>H',d[i:i+2])[0]!=0xffff: i+=4
    # find record table: after terminator; locate by matching table copy later
    return d,n

def check(m,cpu,patched,fid,lo,hi,where):
    d,n=file_fields(fid)
    assert hi-lo==n,(hi-lo,n)
    bad=0; P=None; addrs=[]
    # original fields: records in file follow the ID table; find them by matching words 4..9 of each record
    for k,idx in enumerate(range(lo,hi)):
        a=decode(m,cpu,idx,patched); addrs.append(a)
        mem=bytes(m.r(a+j,1) for j in range(24))
        if P is None:
            P=d.find(mem)
        # derive file offset via relative position to image lo
    base=addrs[0]
    for k,a in enumerate(addrs):
        mem=bytes(m.r(a+j,1) for j in range(24))
        if d.find(mem)<0: bad+=1
    regions=set()
    for a in addrs:
        regions.add('cart' if 0x02400000<=a<0x02800000 else 'wramL' if 0x00200000<=a<0x00300000 else 'hwram' if 0x06000000<=a<0x06100000 else hex(a))
    print(f'F{fid:03d} images {lo}-{hi} where={sorted(regions)} data-mismatch={bad}/{n}')
    return regions,bad

def run(patched, p1, p2, cart=0x5C):
    exe='out/F000.PRF' if patched else 'disc/F000.PRF'
    m,cpu=make(exe,cart)
    boot(m,cpu,patched)
    m.w(0x0605c981,1,0xff); m.w(0x060feb18,1,p1); m.w(0x060feb20,1,p2)
    fn = 0x002ff8c6 if patched else 0x060351d4
    c0=r32(m,0x060f9b3c)
    cpu.call(fn,p1); c1=r32(m,0x060f9b3c)
    m.log=[x for x in m.log if isinstance(x[0],str)]
    cpu.call(fn,p2); c2=r32(m,0x060f9b3c)
    reads=[x for x in m.log if x[0]=='read']
    print('P2 reads (file,dest,size,tmode):',[(f,hex(b),s,t) for _,f,b,s,t in reads][:8], '...', len(reads))
    print('counters',c0,c1,c2,'range',r32(m,0x002ff800) if patched else None, r32(m,0x002ff804) if patched else None)
    print('heaplist',hex(r32(m,0x0605daf4)),hex(r32(m,0x0605daf8)),'tmode insn',hex(m.r(0x06038df2,2)))
    return m,cpu,c0,c1,c2

for patched,p1,p2,cart in [(False,2,3,0x5c),(True,2,3,0x5c),(True,6,4,0x5c),(True,2,3,0xff)]:
    print('====', 'patched' if patched else 'original', p1,p2,'cart',hex(cart))
    m,cpu,c0,c1,c2=run(patched,p1,p2,cart)
    full = patched and cart==0x5c
    fid1 = 53+2*p1 if full else 35+2*p1
    fid2 = 53+2*p2 if full else 35+2*p2
    d1,n1=file_fields(fid1); d2,n2=file_fields(fid2)
    check(m,cpu,patched,fid1,c0,c0+n1,'p1')
    check(m,cpu,patched,fid2,c1,c1+n2,'p2')
