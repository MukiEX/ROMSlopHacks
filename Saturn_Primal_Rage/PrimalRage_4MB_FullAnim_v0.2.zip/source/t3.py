import sys; sys.path.insert(0,'/home/claude/pr')
exec(open('/home/claude/pr/t1.py').read().split('if __name__')[0])
def heapfree(m):
    out=[]
    for slot in (0x0605daf4,0x0605daf8):
        h=r32(m,slot); tot=0; big=0; b=r32(m,h)
        while b:
            s=r32(m,b+4); tot+=s; big=max(big,s); b=r32(m,b)
        out.append((hex(h),tot,big))
    return out
def match(patched,p1,p2,stage=0,cart=0x5c):
    exe='out/F000.PRF' if patched else 'disc/F000.PRF'
    m,cpu=make(exe,cart)
    boot(m,cpu,patched)
    m.w(0x060f954c,4,stage)
    try:
        cpu.call(0x0600c714,p1,p2)
    except Exception as e:
        print('  FAILED:',e, 'steps',cpu.steps); return m,cpu
    opens=[x[1] for x in m.log if x[0]=='open']
    print(f'  {"patched" if patched else "orig   "} p1={p1} p2={p2} files={opens} imgs={r32(m,0x060f9b3c)} free={heapfree(m)} range=({r32(m,0x002ff800)},{r32(m,0x002ff804)})')
    return m,cpu
if __name__=='__main__':
    for p1,p2 in [(3,3),(2,3),(0,5)]:
        match(False,p1,p2)
    for p1 in range(7):
        for p2 in range(7):
            match(True,p1,p2)
