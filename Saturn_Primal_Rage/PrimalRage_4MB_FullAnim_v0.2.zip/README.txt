PRIMAL RAGE (USA, Sega Saturn) - 4MB RAM CART FULL-ANIMATION HACK  v0.2 (untested on emulator/hardware)
=====================================================================================================

Apply to:  Primal Rage (USA) (Track 01).bin   (redump, Mode 1/2352)
           CRC32 before: 5AFEE626   after: CE92A0BD (default) / FD05FCA6 (uncached variant)
Patches:   .bps (Floating IPS, ROM Patcher JS, beat) or .ips. Only Track 01 changes; keep your .cue
           and the audio tracks as they are.

What it does
------------
With a 4MB Extended RAM Cartridge (ID 0x5C) inserted, normal (non-mirror) matches load the full
"mirror match" animation set for BOTH fighters:
  - Player 1's full set goes into Work RAM, exactly where a mirror match would put it.
  - Player 2's full set (~1.47MB) goes into the first 2MB of the cart.
Without the cart (or with a 1MB cart), the game runs the original code path unchanged.

Cart indicator: when a 4MB cart is detected, the title screen shows "4MB RAM CART ACTIVE" in
the large title font, centered directly under the "SATURN V1.4U" version line. It uses the same
check the loader does (cart ID 0x5C), so if you see the line, the full-animation loading is on.
No line means the game will use its normal reduced sets.
Mirror matches and the two clone pairings (T-rex vs T-rex, ape vs ape) are also left on the
original path; they already use large sets.

How it works (addresses are RAM addresses; the executable F000.PRF loads at 0x06004000)
-------------------------------------------------------------------------------------
- Boot entry (literal @0x06004008) now runs a stub that copies 484 bytes of hack code to the
  last 2KB of Work RAM-L (0x002FF800). The KRB1 heap is shortened by 2KB (literal @0x06036130).
- Match loader's fighter call (literal @0x0600C7E0) -> my_fighter. When the cart is present and
  the match is normal, it loads the compressed set F(053+2c) for each player, plus that player's
  normal VDP1-resident set F(036+2c). For P2 it initializes the cart (0x257EFFFE=1,
  ASR0=0x23301FF0, AREF=0x13), builds a heap in the cart and makes it the only heap. It also
  switches GFS to CPU transfer mode (SCU DMA can't write to the cart), then restores both afterwards.
- Relocation (literal @0x06037074) -> my_reloc: cart addresses are stored as a cart-relative offset.
- Sprite decompress call (literal @0x06034AC4) -> my_draw records the image index. The source
  decode inside 0x06034608 (0x0603466C-0x0603467F) calls my_decode, which returns a cart address
  for images in P2's index range and the original Work RAM-L/H decode otherwise.
- Image-table reset (literal @0x06036CF8) -> my_reset clears the P2 range whenever the game
  restarts image numbering.
- Title screen (literal @0x0602596C, the call that closes the title text block right after the
  version line) -> my_title. If cart ID is 0x5C it calls the game's own print routine
  0x0603662C(x=centered, row 6, "4MB RAM CART ACTIVE", attr 0x4003, the version line's style),
  then continues to 0x060366E8.

Variants
--------
Default: the decompressor reads the cart through the cached address 0x024xxxxx, the same way the
game reads its own sprite data in Work RAM.
"uncached cart reads": reads via 0x224xxxxx. Use this one if player 2's sprites ever show garbage
(a stale-cache problem), at some cost in speed.

Testing done
------------
No emulator or Saturn could be run here. The patch was checked by running the game's own SH-2 code
in a purpose-built interpreter:
  - The full match loader 0x0600C714 ran for all 49 character pairings, and the heaviest pairings ran
    on all 8 stages. There were no allocation failures. Work RAM-H headroom stayed at 40-60KB, the
    same range as an unpatched mirror match. Peak use was 2,280 of 2,760 frame-ID slots and 1,918 of
    2,400 image slots.
  - Every image of both full sets decodes to the right bytes from the disc file, with P1's in
    Work RAM and P2's in the cart.
  - The real draw routine 0x06034608 receives cart source addresses for P2 and Work RAM addresses
    for P1.
  - The title text block, rendered into VDP2 memory: the new line appears on rows 6-7 under the
    version line with a 4MB cart, and nothing appears with no cart or a 1MB cart.
  - The rebuilt track's EDC/ECC was validated, and re-extracting the file system gives back the
    patched F000 with every other file byte-identical.

Things to watch when testing
----------------------------
1. Speed: P2 frames are decompressed from the cart, about 4x slower memory than Work RAM-L.
   Watch for slowdown during heavy moments.
2. A few frame IDs exist only in the reduced sets: 0x2C00 (characters 0 and 5), 0x15B8 (1), and
   0x1370/0x1371/0x13E7 (6). If one is ever requested, the game's lookup returns image 0, so one
   frame of an animation could show the wrong sprite. Mirror matches already run without these IDs.
3. Title notice placement: rows 6-7 sit right under the version line. If it overlaps artwork,
   the row is the "mov #6,r5" in my_title (source/build.py) and is easy to move.
4. Emulators: enable the 4MB Extended RAM cart (Mednafen: ss.cart "extram4", Kronos/Yabause:
   "4 Mbyte RAM" cartridge). On hardware, use an official 4MB cart or a compatible 4-in-1 /
   Action Replay cart; ODEs that expose RAM cart emulation should also work.
